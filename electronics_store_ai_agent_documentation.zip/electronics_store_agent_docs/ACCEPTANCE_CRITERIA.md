# Acceptance Criteria / Definition of Done

## Global
- [ ] App runs in local development.
- [ ] No secrets committed to source control.
- [ ] Admin routes are protected.
- [ ] Public pages are accessible without authentication.
- [ ] RTL and LTR both work.
- [ ] Mobile layout is usable without horizontal overflow except intentional comparison areas.
- [ ] Loading/empty/error states exist for data-driven views.
- [ ] Store-specific content comes from the database/configuration.

## Products
- [ ] Admin can create a product.
- [ ] Admin can edit a product.
- [ ] Admin can activate/deactivate a product.
- [ ] Admin can manage images.
- [ ] Admin can define specifications.
- [ ] Public users see only active products.
- [ ] Product page has stable URL.
- [ ] Price and availability are clear.

## Categories & Brands
- [ ] Admin can CRUD/reorder categories.
- [ ] Product can be assigned to a category.
- [ ] Filters can use categories.
- [ ] Brands can be managed or loaded from product data.

## Search / Filters / Sorting
- [ ] Search returns relevant products.
- [ ] Arabic/English text works where data exists.
- [ ] Multiple filters can be combined.
- [ ] Clear-all filters works.
- [ ] Sorting updates results correctly.
- [ ] Query/filter state can be shared/bookmarked where implemented.

## Offers
- [ ] Admin can create an offer.
- [ ] Active offer appears in offer surfaces.
- [ ] Expired offer is not presented as active.
- [ ] Old/new price display is consistent.
- [ ] Countdown works when end time exists.

## Homepage
- [ ] Admin can enable/disable sections.
- [ ] Admin can reorder sections.
- [ ] Featured products can be selected.
- [ ] New arrivals work.
- [ ] Best sellers work using manual/metric mode.
- [ ] Deal of the Day works.

## Engagement
- [ ] Favorite toggle works without mandatory account.
- [ ] Recently viewed list works.
- [ ] Compare supports multiple products.
- [ ] Compare handles missing specifications gracefully.
- [ ] Share uses native sharing when available and fallback when not.
- [ ] WhatsApp message contains product context.
- [ ] Quick actions work from product cards.

## QR
- [ ] Every public product has a canonical URL.
- [ ] QR code resolves to the correct product page.
- [ ] QR can be shown from product/admin experience.

## Theme / Store Settings
- [ ] Store logo/name are configurable.
- [ ] Contact/social/address/hours are configurable.
- [ ] Theme preset works.
- [ ] Color overrides work without breaking contrast.

## Analytics
- [ ] Product view events are recorded.
- [ ] Search events are recorded.
- [ ] WhatsApp/phone/share events are recordable.
- [ ] Admin dashboard can surface basic metrics.
- [ ] No unnecessary personal data is collected.

## PWA / SEO
- [ ] Manifest exists.
- [ ] App has suitable icons.
- [ ] Dynamic metadata works for products.
- [ ] Open Graph data works.
- [ ] Sitemap/robots are configured.

## AI Coming Soon
- [ ] AI entry point is visible.
- [ ] Clicking it opens a polished Coming Soon state.
- [ ] No AI request is sent in v1.
- [ ] No fake AI answer is displayed.
- [ ] Arabic/English Coming Soon content exists.

## Future Notifications
- [ ] Architecture can represent restock and price-drop subscriptions.
- [ ] Activation is feature-flagged or phase-gated.

## Security
- [ ] RLS policies prevent cross-store data access.
- [ ] Admin mutations require authorization.
- [ ] Input validation is server-side.
- [ ] File uploads are validated.
- [ ] Service-role credentials never reach client code.
