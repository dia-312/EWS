# API Specification

Use Next.js route handlers or a clearly separated server API layer. All admin mutations must be authenticated.

## 1. Public Product API

### GET /api/products
Query params:
- `search`
- `category`
- `brand`
- `minPrice`
- `maxPrice`
- `availability`
- `onSale`
- `sort`
- `page`
- `pageSize`

Response shape:
```json
{
  "data": [],
  "pagination": {
    "page": 1,
    "pageSize": 24,
    "total": 120,
    "totalPages": 5
  }
}
```

### GET /api/products/[slug]
Return complete public product data, images and specifications.

### GET /api/categories
Return active categories in display order.

### GET /api/brands
Return active brands as needed by filters.

### GET /api/offers
Return currently active offers unless explicit admin query is requested.

### GET /api/homepage
Return active homepage sections sorted by `display_order` plus their referenced content.

### GET /api/store
Return safe public store settings/theme/contact information.

## 2. Admin Product API

### POST /api/admin/products
Create a product.

### PATCH /api/admin/products/[id]
Update a product.

### DELETE /api/admin/products/[id]
Soft-delete or deactivate product by default; hard delete only from a safe admin workflow.

### POST /api/admin/products/[id]/duplicate
Optional convenience endpoint.

### POST /api/admin/products/[id]/images
Register/upload product images through authenticated storage flow.

## 3. Admin Category API
- POST /api/admin/categories
- PATCH /api/admin/categories/[id]
- DELETE /api/admin/categories/[id]
- POST /api/admin/categories/reorder

## 4. Admin Offer API
- POST /api/admin/offers
- PATCH /api/admin/offers/[id]
- DELETE /api/admin/offers/[id]

## 5. Homepage API
- GET /api/admin/homepage
- PATCH /api/admin/homepage/sections
- POST /api/admin/homepage/sections
- DELETE /api/admin/homepage/sections/[id]
- POST /api/admin/homepage/reorder

## 6. Settings API
- GET /api/admin/settings
- PATCH /api/admin/settings
- PATCH /api/admin/theme

## 7. Analytics API
### POST /api/analytics/events
Request example:
```json
{
  "eventType": "product_view",
  "productId": "uuid",
  "metadata": {}
}
```

Validate allowed event types server-side.

## 8. Notification API (Future)
- POST /api/notifications/subscribe
- DELETE /api/notifications/subscribe/[id]

## 9. AI API (Future Only)
Do not implement in v1.
Reserved endpoint design:
- POST /api/ai/assistant
- POST /api/ai/recommend

When activated, AI responses must be grounded in current store data and must not invent products, prices or availability.

## 10. Error Contract
Use a predictable shape:
```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Price must be greater than or equal to 0",
    "details": {}
  }
}
```

## 11. Auth Behavior
Unauthenticated admin requests return 401.
Authenticated but unauthorized requests return 403.
Invalid input returns 400/422 as appropriate.
Not found returns 404.
Unexpected server errors return 500 without exposing secrets.
