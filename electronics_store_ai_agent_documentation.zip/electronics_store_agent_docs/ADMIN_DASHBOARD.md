# Admin Dashboard Specification

## 1. Admin Navigation
Suggested navigation:
- Dashboard
- Products
- Categories
- Offers
- Homepage
- Analytics
- Store Settings
- Appearance / Theme
- Notifications (future)
- Admin Users (future)

## 2. Dashboard Home
Show:
- Total active products
- Products on sale
- Out-of-stock products
- Product views
- WhatsApp clicks
- Phone clicks
- Most viewed products
- Most searched terms
- Recent product updates

Provide shortcuts:
- Add Product
- Add Offer
- Manage Homepage
- Edit Store Settings

## 3. Product Management
### Product list
Columns/cards should support:
- Image
- Name
- Category
- Brand
- Price
- Availability
- Sale
- Featured
- Created date
- Actions

Actions:
- Edit
- Duplicate (recommended)
- Preview
- Delete/archive
- Toggle active

### Product editor
Fields:
- Name
- Slug
- Brand
- Category
- Price
- Old price
- Description
- Long description
- Specifications
- Images
- Availability
- Badges
- Featured
- New/automatic behavior
- Sale
- Offer dates
- Sort/order override

Validation examples:
- Name required.
- Category required.
- Price must be >= 0.
- Old price must be >= 0 if present.
- New price should normally be less than old price for an offer.
- Primary image required for publish.

## 4. Category Management
- Add category.
- Edit name/slug.
- Add icon/image.
- Reorder.
- Activate/deactivate.
- Prevent deletion when products depend on category unless products are reassigned or an explicit safe-delete flow exists.

## 5. Offer Management
Admin creates offer-linked product promotions.
Offer fields:
- Product
- Label
- Old price snapshot if required
- New price
- Start/end
- Active flag
- Optional banner image

## 6. Homepage Manager
Recommended UI:
```text
Homepage

☰ Hero Banner        [Edit]
☰ Categories         [Edit]
☰ Special Offers     [Edit]
☰ New Arrivals       [Edit]
☰ Best Sellers       [Edit]
☰ Featured Products  [Edit]
☰ Deal of the Day    [Edit]
☰ Why Choose Us      [Edit]
☰ Contact            [Edit]
```

Requirements:
- Enable/disable sections.
- Reorder sections.
- Configure section title/subtitle.
- Select products where relevant.
- Preview changes before publish if practical.

## 7. Analytics
Admin sees simple, useful charts, not an overwhelming BI dashboard.
Default time filters:
- 7 days
- 30 days
- 90 days

## 8. Store Settings
Sections:
- Identity
- Contact
- Socials
- Address
- Working hours
- Localization
- Currency
- Theme
- SEO defaults

## 9. Appearance
Theme preset selector plus design tokens:
- Primary
- Secondary
- Accent
- Surface/background
- Text
- Border/radius where supported

Do not allow arbitrary CSS injection in normal admin UI.

## 10. Publishing Model
Recommended v1:
- Changes save immediately to database.
- `active/published` flags control visibility.

A future staged draft/publish workflow may be added.

## 11. Admin UX Principles
- Fast paths for frequent tasks.
- Clear destructive action confirmation.
- Autosave only where safe; explicit save for complex forms.
- Toast feedback after successful operations.
- Skeleton states while data loads.
- Empty-state guidance with a primary CTA.
