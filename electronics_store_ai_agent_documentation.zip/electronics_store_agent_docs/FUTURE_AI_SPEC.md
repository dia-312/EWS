# Future AI Specification (Reference Only — Do Not Implement in v1)

## AI Shopping Assistant
Purpose: help a customer discover products using natural language.

Examples:
- "I need a laptop for programming under 3000."
- "Which phone has the best camera in this store?"
- "Show me Samsung phones between 1500 and 2500."

Expected behavior later:
1. Parse intent and constraints.
2. Query current store catalog.
3. Return only products that exist in the store data.
4. Explain why each product matches.
5. Link to product pages.
6. Clearly state when no matching product exists.

## AI Help Me Choose
A guided assistant collects:
- Product type.
- Use case.
- Budget.
- Priorities.
- Optional preferences.

Then returns a small set of matching products with concise reasons.

## Grounding Rules
- Catalog is source of truth.
- Current price and availability come from live database data.
- No invented products.
- No invented specifications.
- No unsupported claims.
- Recommendations must be traceable to stored fields.

## Candidate Architecture Later
User → AI endpoint → intent extraction → structured catalog search → optional embeddings/RAG → response formatter → product cards

AI should remain an assistive interface over the store catalog, not a source of truth.
