# Database Schema Specification

Database: PostgreSQL via Supabase.

The schema should support the current single-store deployment and future multi-store SaaS without requiring a total rewrite.

## 1. Tenancy Strategy
Use a `stores` table even if v1 is deployed for one store. Nearly every business-owned table should include `store_id`.

## 2. Core Tables

### stores
- id UUID PK
- name TEXT NOT NULL
- slug TEXT UNIQUE NOT NULL
- logo_url TEXT
- currency_code TEXT DEFAULT 'ILS'
- locale_default TEXT DEFAULT 'ar'
- timezone TEXT DEFAULT 'Asia/Hebron'
- is_active BOOLEAN DEFAULT true
- created_at TIMESTAMPTZ
- updated_at TIMESTAMPTZ

### store_settings
- store_id UUID PK/FK stores.id
- about_text_ar TEXT
- about_text_en TEXT
- phone TEXT
- whatsapp TEXT
- instagram_url TEXT
- facebook_url TEXT
- address_ar TEXT
- address_en TEXT
- working_hours JSONB
- seo_title TEXT
- seo_description TEXT
- updated_at TIMESTAMPTZ

### store_theme
- store_id UUID PK/FK stores.id
- preset TEXT
- primary_color TEXT
- secondary_color TEXT
- accent_color TEXT
- surface_color TEXT
- logo_variant TEXT
- updated_at TIMESTAMPTZ

### admin_users / profiles
Depending on Supabase Auth design, use `auth.users` plus a public profile/admin membership table.
Recommended fields:
- id UUID PK/FK auth.users.id
- store_id UUID FK stores.id
- role TEXT CHECK (...)
- display_name TEXT
- created_at TIMESTAMPTZ

Future roles: owner, manager, editor, viewer.

### categories
- id UUID PK
- store_id UUID FK
- name_ar TEXT NOT NULL
- name_en TEXT
- slug TEXT NOT NULL
- description_ar TEXT
- description_en TEXT
- image_url TEXT
- icon TEXT
- display_order INTEGER DEFAULT 0
- active BOOLEAN DEFAULT true
- created_at TIMESTAMPTZ
- updated_at TIMESTAMPTZ

Unique constraint: `(store_id, slug)`.

### brands
- id UUID PK
- store_id UUID FK
- name TEXT NOT NULL
- slug TEXT NOT NULL
- logo_url TEXT
- active BOOLEAN DEFAULT true

Unique constraint: `(store_id, slug)`.

### products
- id UUID PK
- store_id UUID FK
- category_id UUID FK
- brand_id UUID FK nullable
- name_ar TEXT NOT NULL
- name_en TEXT
- slug TEXT NOT NULL
- short_description_ar TEXT
- short_description_en TEXT
- description_ar TEXT
- description_en TEXT
- price NUMERIC(12,2) NOT NULL
- old_price NUMERIC(12,2)
- availability TEXT CHECK IN ('in_stock','limited','out_of_stock')
- active BOOLEAN DEFAULT true
- featured BOOLEAN DEFAULT false
- bestseller_manual BOOLEAN DEFAULT false
- created_at TIMESTAMPTZ
- updated_at TIMESTAMPTZ

Unique constraint: `(store_id, slug)`.

### product_images
- id UUID PK
- product_id UUID FK
- storage_path TEXT NOT NULL
- public_url TEXT
- alt_text_ar TEXT
- alt_text_en TEXT
- display_order INTEGER DEFAULT 0
- is_primary BOOLEAN DEFAULT false
- created_at TIMESTAMPTZ

### product_specs
- id UUID PK
- product_id UUID FK
- spec_key TEXT NOT NULL
- value_ar TEXT
- value_en TEXT
- display_order INTEGER DEFAULT 0

Use a child table rather than free-form JSON so compare/search can evolve. A JSONB field can still be added for advanced data later.

### offers
- id UUID PK
- store_id UUID FK
- product_id UUID FK
- title_ar TEXT
- title_en TEXT
- old_price NUMERIC(12,2)
- new_price NUMERIC(12,2)
- start_at TIMESTAMPTZ
- end_at TIMESTAMPTZ
- active BOOLEAN DEFAULT true
- banner_image_url TEXT
- created_at TIMESTAMPTZ
- updated_at TIMESTAMPTZ

### homepage_sections
- id UUID PK
- store_id UUID FK
- type TEXT CHECK IN ('hero','categories','offers','new_arrivals','best_sellers','featured','deal_of_day','banner','trust','contact')
- title_ar TEXT
- title_en TEXT
- subtitle_ar TEXT
- subtitle_en TEXT
- config JSONB
- display_order INTEGER DEFAULT 0
- active BOOLEAN DEFAULT true
- created_at TIMESTAMPTZ
- updated_at TIMESTAMPTZ

The `config` field stores type-specific configuration, while referenced entities remain relational where practical.

### homepage_section_items
- id UUID PK
- section_id UUID FK
- product_id UUID FK nullable
- category_id UUID FK nullable
- display_order INTEGER DEFAULT 0

## 3. Analytics Tables

### analytics_events
- id UUID PK
- store_id UUID FK
- event_type TEXT
- product_id UUID FK nullable
- category_id UUID FK nullable
- search_query TEXT nullable
- session_id TEXT nullable
- metadata JSONB
- created_at TIMESTAMPTZ

Example event types:
- page_view
- product_view
- search
- whatsapp_click
- phone_click
- share
- favorite_add
- favorite_remove
- compare_add
- compare_remove
- qr_scan

Do not store raw sensitive data unnecessarily.

## 4. Notification Tables (Future)
### notification_subscriptions
- id UUID PK
- store_id UUID FK
- product_id UUID FK
- type TEXT CHECK IN ('restock','price_drop')
- channel TEXT CHECK IN ('email','push','other')
- destination TEXT
- status TEXT
- created_at TIMESTAMPTZ

## 5. Optional Ratings (Future)
If ratings are introduced:
- product_ratings
- reviews
Do not expose rating filter in v1 unless real rating data exists.

## 6. Row Level Security
Public storefront:
- Read only active public store/product/category/offer/theme content.

Admin:
- Read/write only rows where `store_id` belongs to the authenticated admin.

Platform operator (future):
- Scoped multi-store administration.

Never use a service-role key in client-side code.

## 7. Indexing Recommendations
Add indexes for:
- `(store_id, active)` on products.
- `(store_id, category_id, active)` on products.
- `(store_id, brand_id, active)` on products.
- `(store_id, created_at DESC)` on products.
- `(store_id, display_order)` on categories/homepage sections.
- `(store_id, event_type, created_at)` on analytics.
- text-search indexes as supported by PostgreSQL for relevant searchable fields.

## 8. Storage Buckets
Suggested buckets:
- store-logos
- store-banners
- product-images
- category-images

Apply sensible file type/size restrictions.
