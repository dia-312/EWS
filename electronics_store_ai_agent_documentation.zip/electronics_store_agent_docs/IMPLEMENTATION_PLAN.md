# Implementation Plan

## Phase 0 — Foundation
1. Initialize Next.js + TypeScript.
2. Install Tailwind and chosen UI primitives.
3. Configure Supabase.
4. Create environment variables safely.
5. Establish app layout, localization and RTL/LTR support.
6. Establish design tokens/theme system.
7. Create seed store and sample catalog data.
8. Add route protection for admin.

## Phase 1 — Core Storefront
1. Navbar/header.
2. Home page shell.
3. Categories.
4. Product listing.
5. Product details.
6. Search.
7. Filters.
8. Sorting.
9. Availability states.
10. Offers.
11. Contact + WhatsApp.
12. Footer.

## Phase 2 — Admin Core
1. Auth.
2. Admin dashboard shell.
3. Product CRUD.
4. Product image upload/reorder.
5. Category CRUD.
6. Brand CRUD where used.
7. Offer management.
8. Store settings.
9. Theme configuration.

## Phase 3 — Homepage CMS
1. Homepage section model.
2. Section CRUD.
3. Enable/disable.
4. Product/category selection.
5. Drag-and-drop ordering.
6. Deal of the Day.
7. Featured/New/Best Seller behavior.

## Phase 4 — Modern Customer Features
1. Favorites.
2. Compare.
3. Recently viewed.
4. Share.
5. Product QR.
6. Quick actions.
7. Related products.
8. Improved empty/error/loading UX.

## Phase 5 — Analytics + PWA
1. Event collection.
2. Admin metrics.
3. Most viewed products.
4. Most searched terms.
5. WhatsApp/phone/share analytics.
6. PWA manifest/icons.
7. Performance optimization.

## Phase 6 — Future/Premium
1. Restock notification.
2. Price drop notification.
3. Multiple admin roles.
4. Advanced analytics.
5. Custom domain/multi-store readiness.
6. Recommendation system.

## Phase 7 — AI Activation
Only after the data quality and product model are stable:
1. Implement AI Shopping Assistant.
2. Implement AI Help Me Choose.
3. Ground responses in store data.
4. Add safeguards for availability and price freshness.
5. Measure AI usage separately.

## Suggested Build Order for an AI Coding Agent
Do not jump directly into feature sprawl.

Sequence:
- Schema/migrations
- Auth/RLS
- Shared UI/design system
- Admin CRUD
- Public catalog
- Homepage CMS
- Engagement features
- Analytics
- PWA/SEO/performance
- Future features

## Definition of Technical Completion per Feature
A feature is not complete until:
1. Database support exists where needed.
2. Server/API behavior exists where needed.
3. UI is responsive.
4. Loading/empty/error/success states exist.
5. Arabic and English are handled.
6. Validation/security are addressed.
7. Acceptance criteria pass.
8. No hardcoded store-specific business data is introduced.
