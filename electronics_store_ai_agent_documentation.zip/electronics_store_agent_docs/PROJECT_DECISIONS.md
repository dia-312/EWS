# Project Decisions Log

This file captures agreed product decisions so the coding agent does not reinterpret them later.

## Decision 1 — Product Type
The product is a **digital storefront system/catalog** for electronics stores, not a generic personal website.

## Decision 2 — Reusability
The same codebase must be reusable for multiple stores through configuration, theme settings and database-driven content.

## Decision 3 — Admin Control
Store owners must manage products, categories, offers, homepage content and store information without developer assistance.

## Decision 4 — Customer Conversion
The main conversion path is direct store contact, especially WhatsApp and phone.

## Decision 5 — Ecommerce Scope
Cart, checkout, payment and shipping are future capabilities, not part of the initial catalog release.

## Decision 6 — AI Scope
AI is a planned feature but **not functional in v1**. The UI should advertise it and show a polished Coming Soon experience.

## Decision 7 — Localization
Arabic and English are supported from the beginning.

## Decision 8 — Favorites
Favorites can work client-side without mandatory customer accounts in v1.

## Decision 9 — Compare
Compare uses structured product specifications and must gracefully handle missing values.

## Decision 10 — Analytics
Analytics should start with useful anonymous engagement events and stay lightweight.
