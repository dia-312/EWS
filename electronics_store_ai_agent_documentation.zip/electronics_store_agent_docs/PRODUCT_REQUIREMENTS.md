# Product Requirements Document (PRD)

## 1. Product Overview
A reusable, modern digital storefront for local electronics stores. Each store gets a branded public website and a private admin dashboard.

The public website behaves like a highly searchable digital catalog rather than a checkout-first ecommerce platform.

## 2. Problem
Many local electronics stores have product information scattered across social media, messaging apps or static pages. Customers need to know what is available, compare products, understand offers and contact the store quickly. Store owners need a simple way to update the catalog without developer involvement.

## 3. Goals
### Customer goals
- Find products quickly.
- Search and filter products easily.
- Understand product specifications and pricing.
- Identify offers and availability.
- Compare alternatives.
- Save or share products.
- Contact the store with product context in one tap.
- Use the site comfortably on mobile.

### Store-owner goals
- Manage products without code.
- Add/remove products from the public catalog.
- Control what appears on the homepage.
- Create and manage offers.
- Update branding/contact information.
- See useful engagement data.
- Reuse the system with minimal customization.

## 4. Non-Goals for v1
- Online checkout.
- Payment processing.
- Shipping management.
- Customer order lifecycle.
- AI inference/recommendation service.

Those capabilities may be added in later phases.

## 5. Personas
### Customer
A visitor using a phone or desktop to browse electronics, compare options and contact a local store.

### Store Admin
A store owner/employee who manages products, categories, offers, homepage content, branding and store information.

### Platform Operator (future)
A SaaS-level administrator who can provision stores, manage subscriptions and monitor tenants.

## 6. Business Model Assumption
The platform should be sellable as a setup/customization service and later as a subscription/Premium feature product.

## 7. Functional Areas
- Storefront
- Catalog
- Product details
- Search
- Filters
- Sorting
- Categories
- Offers
- Featured content
- Homepage CMS
- Engagement tools
- Store contact
- Admin dashboard
- Analytics
- Notifications
- QR/PWA
- Localization
- Customization
- Future AI layer

## 8. Key Business Rules
1. Only active products are publicly visible.
2. Out-of-stock products may remain visible but must show a clear unavailable state.
3. Featured products are manually controlled in v1.
4. New Arrivals may be automatic based on creation date, with optional admin override.
5. Best Sellers may be manually curated initially and later derive from analytics/order data.
6. Offer state is determined by `on_sale` and optional start/end dates.
7. If an offer expires, the storefront must stop presenting it as active.
8. Product prices must be numeric and stored in a consistent currency unit.
9. Product URLs must be stable slugs.
10. Every product must have one primary image; additional images are optional.
11. Product WhatsApp CTA must generate a contextual message containing product name and URL at minimum.
12. The AI entry point must never pretend that AI is already operational in v1.
13. All store identity values must come from database settings/theme configuration.
14. Public users do not need an account to browse, compare, favorite or view recently viewed items in v1; these can use client-side local storage.
15. Admin pages must require authenticated admin access.

## 9. Quality Attributes
### Performance
- Fast first load on mobile.
- Optimized images.
- Pagination or efficient loading for large catalogs.
- Avoid unnecessary client-side rendering.

### Security
- Supabase Auth for admins.
- Row Level Security on database tables.
- Admin routes protected server-side.
- Validate and sanitize admin inputs.
- Never expose service-role secrets to the browser.

### Accessibility
- Keyboard navigable.
- Semantic HTML.
- Visible focus states.
- Accessible labels for icons and controls.
- Sufficient contrast.
- Reduced-motion compatibility where possible.

### SEO
- Metadata per page.
- Product title/description metadata.
- Canonical URLs.
- Open Graph sharing.
- Sitemap and robots configuration.
- Structured product data may be added where appropriate.

## 10. Success Metrics
Initial analytics should support measuring:
- Product views.
- Search queries.
- Product shares.
- WhatsApp clicks.
- Phone clicks.
- Favorite actions.
- Compare actions.
- Popular categories.
- Popular products.

## 11. Release Strategy
### Release 1 — Core
Catalog + admin + homepage CMS + search/filter/sort + offers + contact + localization.

### Release 2 — Modern UX
Compare + favorites + recently viewed + sharing + QR + analytics + themes + PWA.

### Release 3 — Engagement/Premium
Notifications + advanced analytics + recommendation engine + multi-admin.

### Release 4 — AI
AI Shopping Assistant and AI-powered Help Me Choose become functional.
