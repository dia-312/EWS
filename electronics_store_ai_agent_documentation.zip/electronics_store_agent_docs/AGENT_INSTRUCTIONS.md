# Instructions for the AI Coding Agent

## Mission
Build a reusable, production-quality digital storefront system for electronics stores according to this documentation package.

## Non-Negotiable Rules
1. Read all files in this documentation package before implementing major features.
2. Treat `FEATURE_SPECIFICATIONS.md` as the authoritative feature inventory.
3. Do not remove or silently skip documented features.
4. Respect the release phases in `IMPLEMENTATION_PLAN.md`.
5. Do not implement AI functionality in v1. Implement only the visible AI entry point and Coming Soon experience.
6. Never fake AI output.
7. Do not hardcode store-specific products, prices, branding or contact information.
8. Build reusable components and data-driven configuration.
9. Use TypeScript types for database/API models.
10. Validate inputs on the server.
11. Protect admin operations with auth + authorization.
12. Preserve Arabic RTL and English LTR behavior.
13. Avoid unnecessary dependencies.
14. Prefer server-side data fetching where appropriate in Next.js.
15. Optimize images and avoid layout shift.
16. Every feature must have loading, empty and error states where applicable.
17. Keep accessibility in mind for all interactive components.
18. Do not expose secrets or service-role keys in client code.
19. Do not introduce a cart/checkout/payment system into v1 unless explicitly requested.
20. Do not replace the documented stack without a strong technical reason.

## Architecture Rules
- Use a modular folder structure.
- Separate public storefront components from admin components.
- Centralize database access.
- Centralize translations.
- Centralize theme/design tokens.
- Centralize validation schemas.
- Keep product/business models independent of UI.

## Data Rules
- Use UUIDs for database primary keys.
- Use slugs for public URLs.
- Prefer relational tables for queryable product data.
- Use JSONB only for truly flexible configuration.
- Use indexes where query patterns justify them.
- Use soft-disable (`active=false`) instead of destructive deletes when appropriate.

## Admin Rules
- Every CRUD operation must have success and error feedback.
- Destructive operations require confirmation.
- Product forms must support image ordering and primary image selection.
- Homepage ordering must persist reliably.
- Admin must be able to preview public-facing product content.

## UX Rules
- Mobile-first.
- Keep the customer journey short.
- Make price/availability/contact actions obvious.
- Avoid cluttering product cards with too many buttons.
- Use drawers/modals on mobile for filters and secondary actions when helpful.
- Use subtle modern motion only.

## AI Rules for v1
The AI feature is a placeholder only.

Required behavior:
- Show an entry point such as `AI Shopping Assistant`.
- On click show `Coming Soon` in Arabic/English.
- No network call to an AI provider.
- No fake generated recommendations.
- Do not collect user questions for AI unless an explicit non-AI analytics event is intentionally implemented.

Future AI must be grounded in the current store catalog and must not invent inventory, specifications, price or availability.

## Development Workflow
For each feature:
1. Identify its requirements in the docs.
2. Implement schema/API if needed.
3. Implement UI.
4. Add validation and error handling.
5. Test mobile + desktop.
6. Test Arabic + English.
7. Verify acceptance criteria.
8. Refactor duplicated code.

## Before Marking a Phase Complete
- Run lint/type checks.
- Run tests.
- Verify all related acceptance criteria.
- Verify no console errors in key flows.
- Verify responsive behavior.
- Verify admin authorization.

## Suggested Initial Folder Structure
```text
src/
  app/
    (storefront)/
    admin/
    api/
  components/
    storefront/
    admin/
    shared/
  lib/
    supabase/
    validations/
    analytics/
    i18n/
  services/
  types/
  config/
  styles/
```

Adjust to the project conventions only if the resulting architecture remains modular and clear.

## Do Not Overbuild
Do not build every future feature before the core flow works.
Prioritize a stable foundation and preserve extension points for future phases.
