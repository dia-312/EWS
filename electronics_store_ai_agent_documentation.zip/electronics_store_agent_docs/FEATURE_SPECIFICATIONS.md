# Complete Feature Specifications

This is the authoritative feature list. Do not omit a feature because it appears in a later phase; later-phase features must remain documented and architecturally possible.

## A. Storefront & Catalog

### A1. Product Catalog
Display products in responsive cards/grid/list views.
Each product supports:
- Name
- Brand
- Category
- Price
- Optional old price
- Optional discount percentage
- Short description
- Full description
- Primary image
- Additional images
- Availability
- Specifications
- Badges/tags
- Featured state
- Sale state
- Created date

### A2. Product Details
A dedicated canonical page must show:
- Image gallery
- Product title
- Brand/category
- Current price
- Old price if applicable
- Discount badge if applicable
- Availability state
- Description
- Specifications
- Favorite button
- Compare button
- Share button
- WhatsApp inquiry
- Call action where configured
- QR code or QR entry where useful
- Related products

### A3. Categories
Admin can create, edit, reorder, activate/deactivate and delete categories where safe.
Public site shows category navigation and category pages.

### A4. Search
Search by product name and relevant searchable fields such as brand, category and aliases.
V1 should support fast normal text search without AI.
Search must support Arabic and English values where available.

### A5. Filters
Filters may include:
- Category
- Brand
- Price range
- Availability
- On sale
- Rating (only if ratings are later implemented)

Filters should be combinable.

### A6. Sorting
Provide:
- Newest
- Price low to high
- Price high to low
- Name A-Z
- Popular/Most Viewed when analytics data is available

### A7. Availability States
At minimum:
- In Stock
- Limited Stock
- Out of Stock
Admin controls the state.

### A8. Product Badges
Supported examples:
- NEW
- SALE
- FEATURED
- BEST SELLER
- LIMITED
Badges should be data-driven rather than hardcoded.

## B. Homepage CMS

### B1. Dynamic Homepage
Admin controls visible sections and section order.
Suggested sections:
- Hero banner
- Featured categories
- Special offers
- New arrivals
- Best sellers
- Featured products
- Deal of the Day
- Promotional banners
- Trust/why-choose-us section
- Store contact section

### B2. Section Ordering
Provide drag-and-drop ordering in admin where practical. Persist order.

### B3. Featured Products
Admin selects products for featured display and controls order.

### B4. New Arrivals
Automatic mode based on product creation date plus optional manual override.

### B5. Best Sellers
V1: manually curated or based on view metrics. Future: derive from orders when ecommerce exists.

### B6. Deal of the Day
Special visual promotion for one or more chosen products with optional start/end time and countdown.

## C. Offers & Promotions

### C1. Smart Offers
Admin can set:
- Product
- Old price
- New price
- Label
- Start date/time
- End date/time
- Active/inactive

The storefront calculates or displays discount information consistently.

### C2. Offer Countdown
When valid start/end times exist, show countdown for the remaining offer time.

### C3. Expiry Behavior
Expired offers must no longer display as active.

## D. Engagement

### D1. Quick Actions
Product cards may expose:
- View
- Favorite
- Compare
- WhatsApp

### D2. Favorites
Users can save products locally without mandatory account creation in v1.

### D3. Recently Viewed
Keep a limited local list of recently viewed products.

### D4. Compare Products
Users can select products and compare their structured specifications side-by-side.
Comparison must work on mobile with a horizontally scrollable or stacked presentation.

### D5. Share Product
Use the Web Share API where available and provide fallback copy/share options.
Share URL must be canonical.

### D6. WhatsApp Product Inquiry
CTA must generate a contextual WhatsApp message, e.g. product name + current price + product URL.
Phone CTA may be shown when configured.

## E. Discovery & Guidance

### E1. Smart Search (Non-AI v1)
Support normalized search, Arabic/English aliases and common terms. Do not depend on an LLM.

### E2. Help Me Choose — Coming Soon initially
A guided recommendation flow can ask use-case and priorities such as price, performance, camera, battery, gaming or work.
In v1 the entry point must show a polished modal/page with a **Coming Soon** state rather than performing recommendations.

### E3. AI Shopping Assistant — Coming Soon initially
Visible entry point in storefront.
Clicking it opens a branded Coming Soon experience.
No AI call should be made in v1.
Future behavior: answer product questions using store product data only, return product cards and direct links, and never fabricate store inventory/specifications.

## F. Notifications — Future/Premium

### F1. Restock Notification
User can request notification for an out-of-stock product.

### F2. Price Drop Notification
User can request notification when a product price decreases.

### F3. Notification Delivery
Architecture should allow email, browser push or messaging integrations later. Do not overbuild v1.

## G. QR & Physical Store Bridge

### G1. Product QR Code
Every product has a QR code derived from its canonical URL.
Admin can view/download/share the QR representation where practical.

Primary use cases:
- Shelf labels
- Printed price tags
- In-store promotion
- Social media

## H. Store Branding & Customization

### H1. Store Settings
Admin can manage:
- Store name
- Logo
- Hero/banner images
- Primary color
- Secondary/accent color
- Optional font choice from supported safe fonts
- Contact phone
- WhatsApp
- Instagram
- Facebook
- Address
- Working hours
- About text

### H2. Themes
Provide presets such as:
- Modern
- Minimal
- Gaming
- Luxury
- Tech
Themes must be token-based so branding can be overridden.

## I. Media Management

### I1. Image Upload
Admin can upload by picker or drag-and-drop.

### I2. Image Processing
System should support:
- Compression
- Responsive sizing
- Efficient web formats where available
- Reordering
- Primary image selection

### I3. Media Validation
Validate file type and sensible maximum file size/dimensions.

## J. Analytics

### J1. Dashboard Metrics
Track at minimum:
- Visitors/session indicator if analytics implementation allows
- Product views
- Popular products
- Popular categories
- Search terms
- WhatsApp clicks
- Phone clicks
- Share clicks
- Favorite actions
- Compare actions

### J2. Event Tracking
Use a small, extensible event model instead of hardcoding many analytics tables.

### J3. Data Privacy
Do not collect unnecessary personal data. Anonymous engagement metrics are preferred for v1.

## K. Contact & Store Presence

### K1. Contact Section
Show:
- WhatsApp
- Phone
- Address
- Working hours
- Instagram
- Facebook
- Optional map link/embed if configured

### K2. Open/Closed Indicator
Display Open Now / Closed Now based on configured working hours and timezone.

## L. Localization

### L1. Arabic + English
All interface strings must come from translation resources.

### L2. RTL/LTR
Arabic must switch the document layout to RTL correctly.
English must use LTR.

### L3. Product Content
Product content may exist in one or both languages; the data model should permit bilingual content.

## M. PWA / Mobile

### M1. Mobile-first
Core browsing and contact actions must be excellent on small screens.

### M2. Installability
Prepare the site as a PWA where compatible, including manifest and icons.

### M3. Offline Strategy
Do not promise full offline catalog functionality in v1. Only cache safe/static resources as appropriate.

## N. Admin Dashboard

### N1. Dashboard Overview
Provide cards/charts for core metrics and shortcuts.

### N2. CRUD
Admin must manage products, categories, offers, homepage sections and store settings.

### N3. Product Form
Product creation/editing should include validation, preview and image management.

### N4. Bulk-friendly UX
Even without CSV import in v1, the data model and UI should avoid painful one-by-one workflows.

### N5. Preview
Admin should be able to preview a product before publishing.

## O. Future SaaS Features

### O1. Multiple Admin Users
Roles such as Owner, Manager, Editor.

### O2. Multi-store Tenancy
One platform instance can host multiple stores with isolated data.

### O3. Custom Domain
Map a store to a custom domain in a future SaaS release.

## P. Future Ecommerce Layer
Not required in v1, but architecture should not block later addition of:
- Cart
- Checkout
- Orders
- Online payments
- Shipping/delivery
- Customer accounts
- Order notifications
