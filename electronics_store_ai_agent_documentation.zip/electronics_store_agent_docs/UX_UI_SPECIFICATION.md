# UX / UI Specification

## 1. Design Direction
The storefront should feel modern, premium and fast without becoming visually noisy.

Think:
- Clean product cards.
- Strong product photography.
- Clear prices.
- Prominent offers.
- One-tap contact.
- Minimal cognitive load.

The exact colors are store-configurable; do not hardcode a single brand palette.

## 2. Responsive Breakpoints
Use the UI framework defaults unless there is a strong reason to customize.
Prioritize:
- Mobile
- Tablet
- Desktop

## 3. Global Components
Required reusable components:
- Navbar
- Search bar
- Language switcher
- Product card
- Price display
- Discount badge
- Availability badge
- Category card
- Offer banner
- Product gallery
- Specifications table
- Favorite button
- Compare button
- Share button
- WhatsApp CTA
- Call CTA
- Empty state
- Loading skeleton
- Toast/alert
- Modal/drawer
- Breadcrumbs
- Pagination/infinite loading
- Footer
- Coming Soon modal/card

## 4. Home Page Sections
Recommended order (admin can change it):
1. Header/navigation.
2. Hero banner.
3. Featured categories.
4. Special offers.
5. New arrivals.
6. Best sellers.
7. Featured products.
8. Deal of the Day.
9. Why choose us.
10. Contact/store info.
11. Footer.

The actual visible order is data-driven through homepage sections.

## 5. Product Card Requirements
Must show at least:
- Image.
- Name.
- Price.
- Availability.

Optional/contextual:
- Old price.
- Discount.
- Badge.
- Brand.
- Quick actions.

Actions must not make the card feel crowded on mobile. On mobile, use a compact action pattern.

## 6. Product Details UX
Use a two-column desktop layout and stacked mobile layout.
Primary CTA should be WhatsApp/contact, not checkout.

## 7. Search UX
- Search must be visible and easy to reach.
- Support keyboard interaction.
- Show a clean no-results state.
- Preserve search/filter query in URL where practical so results are shareable/bookmarkable.

## 8. Filter UX
Desktop: sidebar or top filter controls.
Mobile: filter drawer/sheet.
Show active filter chips and a clear-all action.

## 9. Compare UX
Maximum recommended selection: 3 or 4 products.
Prevent incompatible compare state if product specifications are missing; show graceful fallbacks such as `—`.

## 10. Favorites UX
Favorite interaction must provide immediate visual feedback.
Persist locally without forcing sign-in.

## 11. Recently Viewed
Keep a small list, e.g. 8–12 products. Use local storage.

## 12. WhatsApp UX
Display WhatsApp CTA prominently.
Generated message should be human-readable and localized.

## 13. Coming Soon UX for AI
This is required in v1.
When user clicks AI:
- Open modal/drawer/page.
- Show AI feature branding.
- Explain that the assistant is coming soon.
- Do not call an AI backend.
- Do not fake generated answers.

Suggested copy:
- Arabic: `مساعد التسوق بالذكاء الاصطناعي — قريبًا`
- English: `AI Shopping Assistant — Coming Soon`

The interaction should feel intentional, not like a disabled broken button.

## 14. Admin UX
Admin interface should prioritize:
- Tables for management.
- Cards for dashboard stats.
- Clear create/edit forms.
- Drag-and-drop for homepage ordering.
- Image preview.
- Search in large product lists.
- Confirmation on destructive actions.

## 15. Accessibility
- Use semantic buttons/links.
- Every icon-only button needs an accessible label.
- Images need alt text.
- Forms need labels and validation messages.
- Preserve focus when modals open/close.
- Ensure RTL layout is tested, not simply mirrored.

## 16. Loading / Empty / Error States
Every data-driven screen must have:
- Loading state.
- Empty state.
- Error state.
- Success feedback after admin mutations.

## 17. SEO / Share Previews
Product pages need dynamic:
- Title.
- Description.
- Open Graph title/description/image.
- Canonical URL.

## 18. Motion
Use subtle motion for:
- Hover.
- Modal transitions.
- Favorite/compare feedback.
- Offer emphasis.
Avoid excessive animation and respect reduced-motion preferences.
